<?php
$sender = 'From: WEB DITZNESIA || <ditznesiaofficial@gmail.com>';

$email = 'yt.ditznesia@gmail.com';
 // GANTI EMAIL KAMU DISINI
?>